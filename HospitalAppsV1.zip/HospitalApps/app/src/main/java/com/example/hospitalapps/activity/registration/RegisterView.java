package com.example.hospitalapps.activity.registration;

public interface RegisterView {

    void showProgress();
    void hideProgress();
    void onAddProgress(String message);
    void onAddError(String message);

}
