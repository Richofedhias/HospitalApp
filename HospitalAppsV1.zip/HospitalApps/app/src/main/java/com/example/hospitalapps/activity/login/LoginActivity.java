package com.example.hospitalapps.activity.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.hospitalapps.R;
import com.example.hospitalapps.SessionManager;
import com.example.hospitalapps.activity.BerandaActivity;
import com.example.hospitalapps.activity.main.MainActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private EditText mNoRekamMedis;
    private EditText mPassword;
    private Button mBtnLogin;

    private static String URL_LOGIN = "https://thetaufiq.xyz/andro/login.php";
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mNoRekamMedis = findViewById(R.id.etLogin_NoMedis);
        mPassword = findViewById(R.id.etLogin_Password);
        mBtnLogin = findViewById(R.id.btn_Login);

        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String noRekamMedis = mNoRekamMedis.getText().toString().trim();
                String password = mPassword.getText().toString().trim();

                if (!noRekamMedis.isEmpty() || !password.isEmpty()){
                    Login(noRekamMedis,password);
                }else {
                    mNoRekamMedis.setError("mohon masukan nomer rekam medis");
                    mPassword.setError("mohon masukan password dengan benar");
                }

//                Intent intent = new Intent(LoginActivity.this, BerandaActivity.class);
//                startActivity(intent);
            }
        });
    }

    private void Login(final String noRekamMedis, final String password) {

        mBtnLogin.setVisibility(View.GONE);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String success = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("login");

                            if (success.equals("1")) {

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject object = jsonArray.getJSONObject(i);

                                    String pasien_nama = object.getString("pasien_nama").trim();
                                    String no_rekam_medis = object.getString("no_rekam_medis").trim();
                                    String pasien_id = object.getString("pasien_id").trim();

                                    sessionManager.createSession(pasien_nama, no_rekam_medis, pasien_id);

                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    intent.putExtra("pasien_nama", pasien_nama);
                                    intent.putExtra("no_rekam_medis", no_rekam_medis);
                                    startActivity(intent);
                                    finish();
                                }
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            mBtnLogin.setVisibility(View.VISIBLE);
                            Toast.makeText(LoginActivity.this, "Disini " + e.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        mBtnLogin.setVisibility(View.VISIBLE);
                        Toast.makeText(LoginActivity.this, "Error "+error.toString(), Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("no_rekam_medis", noRekamMedis);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
