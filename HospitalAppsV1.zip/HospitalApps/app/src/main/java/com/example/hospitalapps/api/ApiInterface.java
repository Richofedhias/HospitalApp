package com.example.hospitalapps.api;

import com.example.hospitalapps.model.Registration;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiInterface {

    @FormUrlEncoded
    @POST("savePendaftar.php")
    Call<Registration> saveRegister(
            @Field("nama") String nama,
            @Field("telpon") String telpon,
            @Field("nomorktp") String nomorktp
    );
}
