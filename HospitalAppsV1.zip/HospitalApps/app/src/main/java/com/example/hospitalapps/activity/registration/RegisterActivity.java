package com.example.hospitalapps.activity.registration;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hospitalapps.R;
import com.example.hospitalapps.activity.InformationRegisterActivity;

public class RegisterActivity extends AppCompatActivity implements RegisterView{

    Button btn_regis;

    EditText et_mNama;
    EditText et_mTelpon;
    EditText et_mNoKtp;

    RegisterPresenter presenter;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        btn_regis = findViewById(R.id.btn_Register);
//        btn_regis.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(RegisterActivity.this, InformationRegisterActivity.class);
//                startActivity(intent);
//            }
//        });

        et_mNama = findViewById(R.id.etRegis_Nama);
        et_mTelpon = findViewById(R.id.etRegis_NoTelp);
        et_mNoKtp = findViewById(R.id.etRegis_NoKTP);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("wait...");

        presenter = new RegisterPresenter(this);

        btn_regis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nama = et_mNama.getText().toString().trim();
                String telpon = et_mTelpon.getText().toString().trim();
                String nomorktp = et_mNoKtp.getText().toString().trim();

                if (nama.isEmpty()){
                    et_mNama.setError("harap masukan nama");
                } else if (telpon.isEmpty()){
                    et_mNama.setError("harap masukan nomor telpon");
                } else if (nomorktp.isEmpty()){
                    et_mNama.setError("harap masukan nomor NIK");
                } else {
                    presenter.saveRegister(nama,telpon,nomorktp);
                    Intent intent = new Intent(RegisterActivity.this, InformationRegisterActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    @Override
    public void showProgress() {
        progressDialog.show();
    }

    @Override
    public void hideProgress() {
        progressDialog.hide();
    }

    @Override
    public void onAddProgress(String message) {
        Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onAddError(String message) {
        Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();
    }
}
