package com.example.hospitalapps.activity;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.hospitalapps.R;

import java.util.ArrayList;

public class ReservasiActivity extends AppCompatActivity {
    private Spinner jenisKelamin, layanan, jenisLayanan, jam, dokter, asuransi1, asuransi2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservasi);
        jenisKelamin = findViewById(R.id.spin_jenisKel);
        layanan = findViewById(R.id.spin_layanan);
        jenisLayanan = findViewById(R.id.spin_jenisLayanan);
        jam = findViewById(R.id.spin_jam);
        dokter = findViewById(R.id.spin_dokter);
        asuransi1 = findViewById(R.id.spin_Asuransi1);
        asuransi2 = findViewById(R.id.spin_Asuransi2);

    }
}
