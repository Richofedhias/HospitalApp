package com.example.hospitalapps;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import com.example.hospitalapps.activity.login.LoginActivity;
import com.example.hospitalapps.activity.main.MainActivity;

import java.util.HashMap;

public class SessionManager {

    SharedPreferences sharedPreferences;
    public SharedPreferences.Editor editor;
    public Context context;
    int PRIVATE_MODE = 0;

    private static final String PREF_NAME = "LOGIN";
    private static final String LOGIN = "IS_LOGIN";
    public static final String PASIEN_NAMA = "PASIEN_NAMA";
    public static final String NO_REKAM_MEDIS = "NO_REKAM_MEDIS";
    public static final String PASIEN_ID = "PASIEN_ID";

    public SessionManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = sharedPreferences.edit();
    }

    public void createSession(String pasien_nama, String no_rekam_medis, String pasien_id){

        editor.putBoolean(LOGIN, true);
        editor.putString(PASIEN_NAMA, pasien_nama);
        editor.putString(NO_REKAM_MEDIS, no_rekam_medis);
        editor.putString(PASIEN_ID, pasien_id);
        editor.apply();
    }

    public boolean isLoggin(){
        return sharedPreferences.getBoolean(LOGIN, false);
    }

    public void checkLogin(){

        if (!this.isLoggin()){
            Intent i = new Intent(context, LoginActivity.class);
            context.startActivity(i);
            ((MainActivity) context).finish();
        }
    }

    public HashMap<String, String> getUserDetail(){

        HashMap<String, String> user = new HashMap<>();
        user.put(PASIEN_NAMA, sharedPreferences.getString(PASIEN_NAMA, null));
        user.put(NO_REKAM_MEDIS, sharedPreferences.getString(PASIEN_ID, null));
        user.put(PASIEN_ID, sharedPreferences.getString(PASIEN_ID, null));

        return user;
    }

    public void logout(){

        editor.clear();
        editor.commit();
        Intent i = new Intent(context, LoginActivity.class);
        context.startActivity(i);
        ((MainActivity) context).finish();

    }
}
