package com.example.hospitalapps.activity.registration;

import android.support.annotation.NonNull;

import com.example.hospitalapps.api.ApiClient;
import com.example.hospitalapps.api.ApiInterface;
import com.example.hospitalapps.model.Registration;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPresenter {

    private RegisterView view;

    public RegisterPresenter(RegisterView view) {
        this.view = view;
    }

    void saveRegister(final String nama, final String telpon, final String nomorktp){
        view.showProgress();
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<Registration> call = apiInterface.saveRegister(nama, telpon, nomorktp);

        call.enqueue(new Callback<Registration>() {
            @Override
            public void onResponse(@NonNull Call<Registration> call, @NonNull Response<Registration> response) {
                view.hideProgress();
                if (response.isSuccessful() && response.body() != null){
                    Boolean succcess = response.body().getSuccess();
                    if (succcess){
                        view.onAddProgress(response.body().getMessage());
                    }else {
                        view.onAddError(response.body().getMessage());
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<Registration> call, @NonNull Throwable t) {
                view.hideProgress();
                view.onAddError(t.getLocalizedMessage());
            }
        });
    }

}
