package com.example.hospitalapps;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class BerandaActivity extends AppCompatActivity {
    String[] nama = {"Reservasi", "Cek Antrian", "Daftar Dokter", "Profile"};
    int[] gambar = {R.drawable.ic_reservation,R.drawable.ic_queue,R.drawable.ic_doctor,R.drawable.ic_account};
    GridView gridView;
    TextView namaMenu;
    ImageView gambarMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);
        gridView = findViewById(R.id.gridBeranda);

        CustomAdapter customAdapter = new CustomAdapter();
        gridView.setAdapter(customAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });



    }

    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return gambar.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = getLayoutInflater().inflate(R.layout.row_menu,null);

            gambarMenu = v.findViewById(R.id.images);
            namaMenu = v.findViewById(R.id.nama);

            namaMenu.setText(nama[position]);
            gambarMenu.setImageResource(gambar[position]);
            return v;
        }
    }
}
